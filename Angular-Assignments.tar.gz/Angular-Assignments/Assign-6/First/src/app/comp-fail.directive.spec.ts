import { CompFailDirective } from './comp-fail.directive';

describe('CompFailDirective', () => {
  it('should create an instance', () => {
    const directive = new CompFailDirective();
    expect(directive).toBeTruthy();
  });
});
