import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marvellous-com',
  templateUrl: './marvellous-com.component.html',
  styleUrls: ['./marvellous-com.component.css']
})
export class MarvellousComComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
