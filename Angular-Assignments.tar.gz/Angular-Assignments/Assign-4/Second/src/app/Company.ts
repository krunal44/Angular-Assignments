export interface CompanyInterface
{   
    Name: String
}