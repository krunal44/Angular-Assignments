import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pl',
  templateUrl: './pl.component.html',
  styleUrls: ['./pl.component.css']
})
export class PLComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
