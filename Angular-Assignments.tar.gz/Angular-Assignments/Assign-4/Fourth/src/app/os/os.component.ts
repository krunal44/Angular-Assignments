import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-os',
  templateUrl: './os.component.html',
  styleUrls: ['./os.component.css']
})
export class OsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
